# Paperplane PDF Organizer for Windows

This Tauri wrapper packages the HTML app as an offline Windows MSI. PDF.js, pdf-lib, and JSZip are copied into the Vite build from local npm packages, so the packaged app does not fetch runtime libraries from CDNs.

## Build locally on Windows

Install Node.js 22, Rust, Microsoft C++ Build Tools, and WebView2; then run:

```powershell
npm install
npm run tauri -- build --bundles msi
```

The installer is written under `src-tauri/target/release/bundle/msi/`. Its WebView2 offline installer is bundled to support installing without internet; this adds about 127 MB to the installer.

## Build with GitHub Actions

The `Build Windows MSI` workflow runs on Windows and uploads the MSI as a workflow artifact. Download the artifact from the completed Actions run.
