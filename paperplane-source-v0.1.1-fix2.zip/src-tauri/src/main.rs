#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri_plugin_fs::FsExt;

#[tauri::command]
fn allow_export_directory(app: tauri::AppHandle, path: String) -> Result<(), String> {
    let metadata = std::fs::metadata(&path).map_err(|error| error.to_string())?;
    if !metadata.is_dir() {
        return Err("The selected export location is not a folder.".into());
    }
    app.fs_scope()
        .allow_directory(path, false)
        .map_err(|error| error.to_string())
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_updater::Builder::new().build())
        .invoke_handler(tauri::generate_handler![allow_export_directory])
        .run(tauri::generate_context!())
        .expect("failed to run Paperplane PDF Organizer");
}
