import { copyFile, mkdir } from 'node:fs/promises';

const files = [
  ['node_modules/pdfjs-dist/build/pdf.min.js', 'public/vendor/pdf.min.js'],
  ['node_modules/pdfjs-dist/build/pdf.worker.min.js', 'public/vendor/pdf.worker.min.js'],
  ['node_modules/pdf-lib/dist/pdf-lib.min.js', 'public/vendor/pdf-lib.min.js'],
];

await mkdir('public/vendor', { recursive: true });
for (const [source, destination] of files) await copyFile(source, destination);
