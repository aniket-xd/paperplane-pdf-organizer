# Paperplane PDF Organizer

Paperplane is an offline-first PDF page organizer for Windows. It brings common page-level tasks into one visual workspace, with page thumbnails and a scissors marker for choosing split points.

## Features

- Merge PDFs and add image files as pages
- Split a PDF at visual page markers and save numbered output files
- Rotate, delete, extract, and reorder pages
- Reduce a PDF toward a chosen file size
- Deshadow scanned pages, compare before and after, then export at A4 or Legal size
- Open-source Windows desktop app built with Tauri; PDF work is processed locally

## Get started

Download the latest Windows MSI from [GitHub Releases](https://github.com/aniket-xd/paperplane-pdf-organizer/releases). The app does not upload documents for processing. An internet connection is needed to check for app updates.

## Build from source

Requirements: Windows 10/11, Node.js 22, Rust toolchain, Microsoft C++ Build Tools, and WebView2.

```powershell
npm ci
npm run tauri -- build --bundles msi
```

The MSI is created under `src-tauri/target/release/bundle/msi/`. To run the web UI during development:

```powershell
npm run dev
```

Some desktop-only features require the Tauri shell and will not work in a plain browser.

## Contributing

Issues and pull requests are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request. Keep changes focused, explain user-visible behavior, and do not include PDFs, signing keys, tokens, or other private data in commits.

## License and credits

Original project code is released under the [MIT License](LICENSE). The project is maintained by Aniket Aggarwal, with development assistance from OpenAI Codex. Third-party components retain their own licenses; see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

Paperplane is an independent project and is not affiliated with, sponsored by, or endorsed by Smallpdf or Lensup. Their names are referenced only to describe inspiration for general document-workflow ideas; no proprietary source code or branding is included.
